import sqlite3
import os
from werkzeug.security import generate_password_hash

DB_PATH = os.path.join(os.path.dirname(__file__), "basera.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(seed=True):
    conn = get_db()
    with open(os.path.join(os.path.dirname(__file__), "schema.sql")) as f:
        conn.executescript(f.read())
    if seed:
        seed_data(conn)
    conn.commit()
    conn.close()


def seed_data(conn):
    owners = [
        ("Radhika Shenoy", "radhika.owner@basera.app", "9820011223",
         generate_password_hash("owner123"), "owner"),
        ("Imran Qureshi", "imran.owner@basera.app", "9833344556",
         generate_password_hash("owner123"), "owner"),
    ]
    conn.executemany(
        "INSERT INTO users (name, email, phone, password_hash, role) VALUES (?,?,?,?,?)",
        owners,
    )

    conn.execute(
        "INSERT INTO users (name, email, phone, password_hash, role) VALUES (?,?,?,?,?)",
        ("Demo Tenant", "tenant@basera.app", "9900112233",
         generate_password_hash("tenant123"), "tenant"),
    )

    listings = [
        (1, "Sunny 1BHK near Andheri station", "Mumbai", "Andheri West",
         "1BHK", "Semi-furnished", 2800000, 5600000, 480, "2026-08-01",
         "WiFi, Lift, Power backup, Water 24x7",
         "Bright first-floor flat two minutes from the station, quiet "
         "residential lane, ideal for a working professional or couple."),
        (1, "Cozy PG room for working women", "Mumbai", "Bandra East",
         "PG", "Fully furnished", 1400000, 1400000, 120, "2026-07-25",
         "WiFi, Meals included, Laundry, CCTV",
         "Single occupancy PG room in a women-only building, walking "
         "distance to the station, meals and WiFi included in rent."),
        (2, "Spacious 2BHK, family-friendly society", "Mumbai", "Powai",
         "2BHK", "Unfurnished", 4200000, 8400000, 850, "2026-08-15",
         "Lift, Parking, Gym, Garden, Power backup",
         "Large gated-society flat with a park view, good schools nearby, "
         "vegetarian building, ideal for families."),
        (2, "Compact 1RK, walk to IT park", "Pune", "Hinjewadi",
         "1RK", "Fully furnished", 1500000, 3000000, 220, "2026-07-20",
         "WiFi, Parking, Power backup",
         "Ready-to-move studio ten minutes from the IT park, perfect for "
         "someone starting a new job in the city."),
        (1, "Shared room, all bachelors welcome", "Pune", "Kothrud",
         "Room", "Semi-furnished", 900000, 900000, 140, "2026-07-22",
         "WiFi, Water 24x7",
         "Shared room in a 3BHK flat, two other bachelors already staying, "
         "friendly landlord lives in the same building."),
        (2, "New-to-city special: 1BHK near tech park", "Bengaluru", "Whitefield",
         "1BHK", "Fully furnished", 2200000, 4400000, 430, "2026-08-05",
         "WiFi, Lift, Parking, Power backup, Modular kitchen",
         "Fully set up flat — move in with just your bags. Five minute "
         "walk to the tech park, popular with people relocating for work."),
    ]
    conn.executemany(
        """INSERT INTO listings
           (owner_id, title, city, locality, room_type, furnishing,
            rent_cents, deposit_cents, area_sqft, available_from,
            amenities, description)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        listings,
    )


if __name__ == "__main__":
    init_db()
    print("Database initialized and seeded at", DB_PATH)
