# Basera — find a room or flat, no brokerage

A complete two-sided rental marketplace: Python/Flask backend + SQLite
database + server-rendered HTML/CSS frontend. Built for people new to a
city looking for a room or flat, and for owners who want tenants to find
them directly.

## What's included

**For tenants (people looking for a place):**
- Browse and search listings by city, locality/keyword, room type, and
  max rent
- View full listing details: rent, deposit, area, amenities, availability,
  description
- Save listings to a personal shortlist
- Message the owner directly from the listing page
- Dashboard showing everything they've saved and every message they've sent

**For owners (people listing a property):**
- Post a listing: title, city, locality, room type (Room / 1RK / 1BHK /
  2BHK / 3BHK / PG), furnishing, rent, deposit, area, amenities,
  availability date, description
- Edit or delete their own listings
- Mark a listing "rented" (hides it from search without deleting it)
- Dashboard showing all their listings and how many people have messaged
  about each one
- Read every tenant's message along with their phone/email to follow up
  directly — no middleman

## Run it locally

Requires Python 3.9+.

```bash
cd basera
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

python3 database.py             # creates & seeds basera.db
python3 app.py                  # starts the server
```

Then open **http://127.0.0.1:5001** in your browser.

To reset the database (wipes all listings/users/messages and reseeds the
demo data), delete `basera.db` and re-run `python3 database.py`.

## Demo accounts

- **Tenant:** tenant@basera.app / tenant123
- **Owner:** radhika.owner@basera.app / owner123
- **Owner:** imran.owner@basera.app / owner123

Or register your own account and pick "I'm looking for a room or flat"
(tenant) or "I'm listing my property" (owner) at sign-up.

## Project structure

```
basera/
  app.py                  Flask app: browsing, auth, inquiries, favorites, owner dashboard
  database.py              DB connection + seed data
  schema.sql                Table definitions
  templates/                 Jinja2 HTML templates
  static/css/style.css        Design system / styling
  static/js/main.js            Small progressive-enhancement JS
  basera.db                    SQLite database file (created by database.py)
```

## Notes / where to go next

- **Photos**: the design currently works without any images (the cards are
  styled as paper notices). To add real photos, you'd add an `image_url`
  column to `listings` and either accept uploaded files or image URLs.
- **Verification**: there's no ID/property verification step — anyone can
  register as an owner and post. For a public launch you'd want some kind
  of phone/email verification and maybe manual review of new listings.
- **Notifications**: owners currently have to check their dashboard to see
  new messages. Adding email or SMS notifications when a tenant sends an
  inquiry would make this much stickier for owners.
- **Secret key**: `app.py` reads `SECRET_KEY` from the environment, falling
  back to a dev default — set a real one before deploying publicly.
- **Deploying**: the built-in server (`python3 app.py`) is for local
  development only. For production, run behind a WSGI server such as
  gunicorn (`gunicorn -w 4 app:app`) and a reverse proxy like nginx.
