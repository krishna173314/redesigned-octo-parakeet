DROP TABLE IF EXISTS favorites;
DROP TABLE IF EXISTS inquiries;
DROP TABLE IF EXISTS listings;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('tenant', 'owner')),
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    city TEXT NOT NULL,
    locality TEXT NOT NULL,
    room_type TEXT NOT NULL,          -- Room, 1RK, 1BHK, 2BHK, 3BHK, PG
    furnishing TEXT NOT NULL,         -- Unfurnished, Semi-furnished, Fully furnished
    rent_cents INTEGER NOT NULL,
    deposit_cents INTEGER NOT NULL,
    area_sqft INTEGER,
    available_from TEXT NOT NULL,
    amenities TEXT,                   -- comma separated
    description TEXT,
    status TEXT NOT NULL DEFAULT 'active',   -- active, rented
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(owner_id) REFERENCES users(id)
);

CREATE TABLE inquiries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    listing_id INTEGER NOT NULL,
    tenant_id INTEGER NOT NULL,
    message TEXT NOT NULL,
    move_in_by TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY(listing_id) REFERENCES listings(id),
    FOREIGN KEY(tenant_id) REFERENCES users(id)
);

CREATE TABLE favorites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id INTEGER NOT NULL,
    listing_id INTEGER NOT NULL,
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(tenant_id, listing_id),
    FOREIGN KEY(tenant_id) REFERENCES users(id),
    FOREIGN KEY(listing_id) REFERENCES listings(id)
);
