import os
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from werkzeug.security import generate_password_hash, check_password_hash

from database import get_db, init_db, DB_PATH

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")

ROOM_TYPES = ["Room", "1RK", "1BHK", "2BHK", "3BHK", "PG"]
FURNISHING_TYPES = ["Unfurnished", "Semi-furnished", "Fully furnished"]


# ---------- helpers ----------

def get_current_user():
    if "user_id" not in session:
        return None
    if not hasattr(g, "_user"):
        db = get_db()
        g._user = db.execute(
            "SELECT * FROM users WHERE id = ?", (session["user_id"],)
        ).fetchone()
        db.close()
    return g._user


@app.context_processor
def inject_globals():
    return {"current_user": get_current_user()}


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please sign in to continue.", "error")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def role_required(role):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            user = get_current_user()
            if not user or user["role"] != role:
                flash(f"This page is only available to {role} accounts.", "error")
                return redirect(url_for("index"))
            return view(*args, **kwargs)
        return wrapped
    return decorator


def format_price(cents):
    if cents is None:
        return "—"
    return f"₹{cents/100:,.0f}"


app.jinja_env.filters["price"] = format_price
app.jinja_env.globals["ROOM_TYPES"] = ROOM_TYPES
app.jinja_env.globals["FURNISHING_TYPES"] = FURNISHING_TYPES


# ---------- browse ----------

@app.route("/")
def index():
    db = get_db()
    q = request.args.get("q", "").strip()
    city = request.args.get("city", "").strip()
    room_type = request.args.get("room_type", "")
    max_rent = request.args.get("max_rent", "").strip()

    sql = "SELECT listings.*, users.name AS owner_name FROM listings JOIN users ON users.id = listings.owner_id WHERE listings.status = 'active'"
    params = []
    if q:
        sql += " AND (listings.title LIKE ? OR listings.locality LIKE ? OR listings.city LIKE ?)"
        params += [f"%{q}%"] * 3
    if city:
        sql += " AND listings.city = ?"
        params.append(city)
    if room_type:
        sql += " AND listings.room_type = ?"
        params.append(room_type)
    if max_rent:
        try:
            sql += " AND listings.rent_cents <= ?"
            params.append(int(float(max_rent) * 100))
        except ValueError:
            pass
    sql += " ORDER BY listings.created_at DESC"
    listings = db.execute(sql, params).fetchall()

    cities = [r["city"] for r in db.execute(
        "SELECT DISTINCT city FROM listings ORDER BY city"
    ).fetchall()]

    favorite_ids = set()
    user = get_current_user()
    if user and user["role"] == "tenant":
        favorite_ids = {
            r["listing_id"] for r in db.execute(
                "SELECT listing_id FROM favorites WHERE tenant_id = ?", (user["id"],)
            ).fetchall()
        }
    db.close()
    return render_template(
        "index.html", listings=listings, q=q, city=city, room_type=room_type,
        max_rent=max_rent, cities=cities, favorite_ids=favorite_ids,
    )


@app.route("/listing/<int:listing_id>")
def listing_detail(listing_id):
    db = get_db()
    listing = db.execute(
        """SELECT listings.*, users.name AS owner_name, users.phone AS owner_phone,
                  users.email AS owner_email
           FROM listings JOIN users ON users.id = listings.owner_id
           WHERE listings.id = ?""",
        (listing_id,),
    ).fetchone()
    if not listing:
        db.close()
        flash("That listing doesn't exist or has been removed.", "error")
        return redirect(url_for("index"))

    is_favorite = False
    user = get_current_user()
    if user and user["role"] == "tenant":
        fav = db.execute(
            "SELECT 1 FROM favorites WHERE tenant_id = ? AND listing_id = ?",
            (user["id"], listing_id),
        ).fetchone()
        is_favorite = fav is not None
    db.close()
    return render_template("listing.html", listing=listing, is_favorite=is_favorite)


# ---------- inquiries & favorites (tenant only) ----------

@app.route("/listing/<int:listing_id>/inquire", methods=["POST"])
@login_required
@role_required("tenant")
def send_inquiry(listing_id):
    message = request.form.get("message", "").strip()
    move_in_by = request.form.get("move_in_by", "").strip()
    if not message:
        flash("Please add a short message for the owner.", "error")
        return redirect(url_for("listing_detail", listing_id=listing_id))
    db = get_db()
    db.execute(
        "INSERT INTO inquiries (listing_id, tenant_id, message, move_in_by) VALUES (?,?,?,?)",
        (listing_id, session["user_id"], message, move_in_by),
    )
    db.commit()
    db.close()
    flash("Your message has been sent to the owner.", "success")
    return redirect(url_for("listing_detail", listing_id=listing_id))


@app.route("/favorites/toggle/<int:listing_id>", methods=["POST"])
@login_required
@role_required("tenant")
def toggle_favorite(listing_id):
    db = get_db()
    existing = db.execute(
        "SELECT id FROM favorites WHERE tenant_id = ? AND listing_id = ?",
        (session["user_id"], listing_id),
    ).fetchone()
    if existing:
        db.execute("DELETE FROM favorites WHERE id = ?", (existing["id"],))
        flash("Removed from saved listings.", "success")
    else:
        db.execute(
            "INSERT INTO favorites (tenant_id, listing_id) VALUES (?,?)",
            (session["user_id"], listing_id),
        )
        flash("Saved to your shortlist.", "success")
    db.commit()
    db.close()
    return redirect(request.referrer or url_for("index"))


@app.route("/tenant/dashboard")
@login_required
@role_required("tenant")
def tenant_dashboard():
    db = get_db()
    inquiries = db.execute(
        """SELECT inquiries.*, listings.title AS listing_title, listings.id AS listing_id
           FROM inquiries JOIN listings ON listings.id = inquiries.listing_id
           WHERE inquiries.tenant_id = ? ORDER BY inquiries.created_at DESC""",
        (session["user_id"],),
    ).fetchall()
    saved = db.execute(
        """SELECT listings.*, users.name AS owner_name FROM favorites
           JOIN listings ON listings.id = favorites.listing_id
           JOIN users ON users.id = listings.owner_id
           WHERE favorites.tenant_id = ? ORDER BY favorites.created_at DESC""",
        (session["user_id"],),
    ).fetchall()
    db.close()
    return render_template("tenant_dashboard.html", inquiries=inquiries, saved=saved)


# ---------- owner dashboard ----------

@app.route("/owner/dashboard")
@login_required
@role_required("owner")
def owner_dashboard():
    db = get_db()
    listings = db.execute(
        """SELECT listings.*,
                  (SELECT COUNT(*) FROM inquiries WHERE inquiries.listing_id = listings.id) AS inquiry_count
           FROM listings WHERE owner_id = ? ORDER BY created_at DESC""",
        (session["user_id"],),
    ).fetchall()
    db.close()
    return render_template("owner_dashboard.html", listings=listings)


@app.route("/owner/listings/new", methods=["GET", "POST"])
@login_required
@role_required("owner")
def new_listing():
    if request.method == "POST":
        db = get_db()
        db.execute(
            """INSERT INTO listings
               (owner_id, title, city, locality, room_type, furnishing,
                rent_cents, deposit_cents, area_sqft, available_from,
                amenities, description)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                session["user_id"],
                request.form["title"].strip(),
                request.form["city"].strip(),
                request.form["locality"].strip(),
                request.form["room_type"],
                request.form["furnishing"],
                int(float(request.form["rent"]) * 100),
                int(float(request.form["deposit"]) * 100),
                int(request.form["area_sqft"]) if request.form.get("area_sqft") else None,
                request.form["available_from"],
                request.form.get("amenities", "").strip(),
                request.form.get("description", "").strip(),
            ),
        )
        db.commit()
        db.close()
        flash("Listing published.", "success")
        return redirect(url_for("owner_dashboard"))
    return render_template("listing_form.html", listing=None)


@app.route("/owner/listings/<int:listing_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("owner")
def edit_listing(listing_id):
    db = get_db()
    listing = db.execute(
        "SELECT * FROM listings WHERE id = ? AND owner_id = ?",
        (listing_id, session["user_id"]),
    ).fetchone()
    if not listing:
        db.close()
        flash("Listing not found.", "error")
        return redirect(url_for("owner_dashboard"))

    if request.method == "POST":
        db.execute(
            """UPDATE listings SET title=?, city=?, locality=?, room_type=?, furnishing=?,
               rent_cents=?, deposit_cents=?, area_sqft=?, available_from=?,
               amenities=?, description=? WHERE id = ?""",
            (
                request.form["title"].strip(),
                request.form["city"].strip(),
                request.form["locality"].strip(),
                request.form["room_type"],
                request.form["furnishing"],
                int(float(request.form["rent"]) * 100),
                int(float(request.form["deposit"]) * 100),
                int(request.form["area_sqft"]) if request.form.get("area_sqft") else None,
                request.form["available_from"],
                request.form.get("amenities", "").strip(),
                request.form.get("description", "").strip(),
                listing_id,
            ),
        )
        db.commit()
        db.close()
        flash("Listing updated.", "success")
        return redirect(url_for("owner_dashboard"))

    db.close()
    return render_template("listing_form.html", listing=listing)


@app.route("/owner/listings/<int:listing_id>/status", methods=["POST"])
@login_required
@role_required("owner")
def toggle_status(listing_id):
    db = get_db()
    listing = db.execute(
        "SELECT * FROM listings WHERE id = ? AND owner_id = ?",
        (listing_id, session["user_id"]),
    ).fetchone()
    if listing:
        new_status = "rented" if listing["status"] == "active" else "active"
        db.execute("UPDATE listings SET status = ? WHERE id = ?", (new_status, listing_id))
        db.commit()
    db.close()
    return redirect(url_for("owner_dashboard"))


@app.route("/owner/listings/<int:listing_id>/delete", methods=["POST"])
@login_required
@role_required("owner")
def delete_listing(listing_id):
    db = get_db()
    db.execute(
        "DELETE FROM listings WHERE id = ? AND owner_id = ?",
        (listing_id, session["user_id"]),
    )
    db.commit()
    db.close()
    flash("Listing removed.", "success")
    return redirect(url_for("owner_dashboard"))


@app.route("/owner/listings/<int:listing_id>/inquiries")
@login_required
@role_required("owner")
def listing_inquiries(listing_id):
    db = get_db()
    listing = db.execute(
        "SELECT * FROM listings WHERE id = ? AND owner_id = ?",
        (listing_id, session["user_id"]),
    ).fetchone()
    if not listing:
        db.close()
        flash("Listing not found.", "error")
        return redirect(url_for("owner_dashboard"))
    inquiries = db.execute(
        """SELECT inquiries.*, users.name AS tenant_name, users.phone AS tenant_phone,
                  users.email AS tenant_email
           FROM inquiries JOIN users ON users.id = inquiries.tenant_id
           WHERE listing_id = ? ORDER BY inquiries.created_at DESC""",
        (listing_id,),
    ).fetchall()
    db.close()
    return render_template("listing_inquiries.html", listing=listing, inquiries=inquiries)


# ---------- auth ----------

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        phone = request.form.get("phone", "").strip()
        password = request.form.get("password", "")
        role = request.form.get("role", "")

        if not name or not email or not phone or role not in ("tenant", "owner") or len(password) < 6:
            flash("Please fill every field; password needs 6+ characters.", "error")
            return render_template("register.html")

        db = get_db()
        existing = db.execute("SELECT id FROM users WHERE email = ?", (email,)).fetchone()
        if existing:
            db.close()
            flash("An account with that email already exists.", "error")
            return render_template("register.html")

        cur = db.execute(
            "INSERT INTO users (name, email, phone, password_hash, role) VALUES (?,?,?,?,?)",
            (name, email, phone, generate_password_hash(password), role),
        )
        db.commit()
        session["user_id"] = cur.lastrowid
        db.close()
        flash("Welcome to Basera.", "success")
        return redirect(url_for("owner_dashboard") if role == "owner" else url_for("index"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        db.close()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            flash("Signed in.", "success")
            next_url = request.args.get("next") or url_for("index")
            return redirect(next_url)
        flash("Incorrect email or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Signed out.", "success")
    return redirect(url_for("index"))


if __name__ == "__main__":
    if not os.path.exists(DB_PATH):
        init_db()
    app.run(debug=True, host="0.0.0.0", port=5001)
